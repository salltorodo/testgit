public  class Tribulle{

public static void main(String[]adiara){
int tab []={14,7,10,17,9,5,4,13,2,11,6};
int i,k,tmp;


	for (int k=i+1;k<tab.length ;k++){
	
		if([tab[i]<tab[i-1]) {
		tmp=tab[i];
		tab[i]=tab[i-1];
		tab[i-1]=tmp;

}


System.out.println(tab[k]);                    
}
}
}


